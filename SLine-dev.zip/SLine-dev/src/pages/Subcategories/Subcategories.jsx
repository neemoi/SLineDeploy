import React from 'react';
import SubcategoriesItem from './components/SubcategoriesItem.jsx'
import 'bootstrap/dist/css/bootstrap.min.css';

function Subcategories() {
    return (
        <>
            <SubcategoriesItem />
        </>
    );
}

export default Subcategories;
