import AllProductsItem from './components/AllProducts/AllProductsItem.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';

function AllProductsPage() {
    return (
        <div className="allProduct-page">
            <AllProductsItem/>
            </div>
    );
}

export default AllProductsPage;