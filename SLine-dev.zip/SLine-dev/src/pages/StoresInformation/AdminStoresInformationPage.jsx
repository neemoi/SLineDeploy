import Stores from './components/Stores.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';

function StoresInformationPage() {
    return (
        <div className="stores-page">
            <Stores/>
            </div>
    );
}

export default StoresInformationPage;