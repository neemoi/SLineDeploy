import CategoriesItem from './components/Categories/CategoriesItem.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';

function CategoriesPage() {
    return (
        <div className="category-page">
            <CategoriesItem/>
            </div>
    );
}

export default CategoriesPage;