import Profile from './components/Profile/Profile.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';

function ProfilePage() {
    return (
        <div className="profile-page">
            <Profile/>
            </div>
    );
}

export default ProfilePage;